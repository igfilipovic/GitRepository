﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Data.SqlClient; ODKOMENTIRATI ZA SQL SERVER
using System.Data;
using System.Xml;

namespace Random_Student_Picker
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private static List<int> id_stud = new List<int>();
        private static List<string> ime = new List<string>();
        private static List<string> prezime = new List<string>();
        private static List<string> napomena = new List<string>();
        private static int id = 0;
        private string date = DateTime.Now.ToShortDateString();
       
        protected void Page_Load(object sender, EventArgs e)
        {
            lbl_error.Visible = false;
            txt_ime.Focus();
            if (System.IO.File.Exists(HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/baza_studenta" + date + ".xml")))
            {
                lb_lista_studenata.Enabled = true;
            }
        }
        /// <summary>
        /// Upis studenta u genericku listu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_unesi_Click(object sender, EventArgs e)
        {
            if (txt_ime.Text != "" && txt_prezime.Text != "")
            {
                ++id;
                id_stud.Add(id);
                ime.Add(txt_ime.Text.ToUpper());
                prezime.Add(txt_prezime.Text.ToUpper());
                napomena.Add(txt_napomena.Text.ToUpper());
                //SqlConnection c = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["baza_studenta"].ConnectionString);
                //SqlCommand comm = new SqlCommand("insert into student values (@ime,@prezime,@napomena)", c);
                //c.Open();
                //comm.Parameters.AddWithValue("@ime", txt_ime.Text.ToUpper());
                //comm.Parameters.AddWithValue("@prezime", txt_prezime.Text.ToUpper());
                //comm.Parameters.AddWithValue("@napomena", txt_napomena.Text.ToUpper());
                //if (comm.ExecuteNonQuery() == 0)
                //{
                //    lbl_error.Text = "Unos studenta nije uspio. Pokušajte ponovo.";
                //}
                //c.Close();
                txt_ime.Text = "";
                txt_prezime.Text = "";
                txt_napomena.Text = "";
            }
            else
            {
                lbl_error.Text = "Unesite ime i prezime studenta.";
                lbl_error.Visible = true;
            }
        }
        /// <summary>
        /// Izrada XML datoteke
        /// </summary>
        /// <param name="id_stud">ID studenta</param>
        /// <param name="ime">Ime studenta</param>
        /// <param name="prezime">Prezime studenta</param>
        /// <param name="napomena">Dodatno polje za opis</param>
        /// <param name="date">Danasnji dan</param>
        private void SaveToXml(List<int> id_stud, List<string> ime, List<string> prezime, List<string> napomena, string date)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.NewLineOnAttributes = true;
            settings.ConformanceLevel = ConformanceLevel.Fragment;
            XmlWriter writer = XmlWriter.Create(HttpContext.Current.ApplicationInstance.Server.MapPath("~/App_Data/baza_studenta" + date + ".xml"));
            writer.WriteComment("Microsoft Student Partner");
            writer.WriteComment("Datum:" + date);
            writer.WriteStartElement("Studenti");
            for (int i = 0; i < ime.Count; ++i)
            {
                writer.WriteStartElement("Student");
                writer.WriteElementString("Id_stud",id_stud[i].ToString());
                writer.WriteElementString("Ime", ime[i]);
                writer.WriteElementString("Prezime", prezime[i]);
                writer.WriteElementString("Napomena", napomena[i]);
                writer.WriteEndElement();
            }
            writer.WriteEndElement();
            writer.Close();
            writer.Flush();
        }
        /// <summary>
        /// Ciscenje inputa
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btn_ocisti_Click(object sender, EventArgs e)
        {
            txt_ime.Text = "";
            txt_prezime.Text = "";
            txt_napomena.Text = "";
        }
        /// <summary>
        /// Okidac zapisivanja u XML datoteku
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lb_izbor_pobjednika_Click(object sender, EventArgs e)
        {

            if (id_stud.Count > 1)
            {
                SaveToXml(id_stud, ime, prezime, napomena, date);
                Response.Redirect("randomizer.aspx");
            }
            else
            {
                lbl_error.Text = "Unesite barem dva studenta.";
                lbl_error.Visible = true;
            }
        }
    }
}